from flask import Blueprint, jsonify, request

from app.services import admin_service
from app.utils.auth import require_role


admin_bp = Blueprint("admin", __name__)


@admin_bp.route("/api/admin/crear-columnas-diagnostico", methods=["POST"])
@require_role("admin")
def crear_columnas_diagnostico():
    payload, status = admin_service.create_report_columns()
    return jsonify(payload), status


@admin_bp.route("/api/admin/stats", methods=["GET"])
@require_role("admin")
def get_admin_stats():
    payload, status = admin_service.get_stats()
    return jsonify(payload), status


@admin_bp.route("/api/admin/usuarios", methods=["GET"])
@require_role("admin")
def get_usuarios():
    payload, status = admin_service.list_users()
    return jsonify(payload), status


@admin_bp.route("/api/admin/usuarios/<int:id_usuario>", methods=["GET"])
@require_role("admin")
def get_usuario(id_usuario: int):
    payload, status = admin_service.get_user(id_usuario)
    return jsonify(payload), status


@admin_bp.route("/api/admin/usuarios", methods=["POST"])
@require_role("admin")
def crear_usuario():
    payload, status = admin_service.create_user(request.get_json() or {})
    return jsonify(payload), status


@admin_bp.route("/api/admin/usuarios/<int:id_usuario>", methods=["PUT"])
@require_role("admin")
def editar_usuario(id_usuario: int):
    data = request.get_json() or {}
    data["idUsuario"] = id_usuario
    payload, status = admin_service.update_user(data)
    return jsonify(payload), status


@admin_bp.route("/api/admin/usuarios/<int:id_usuario>", methods=["DELETE"])
@require_role("admin")
def eliminar_usuario(id_usuario: int):
    payload, status = admin_service.delete_user(id_usuario)
    return jsonify(payload), status


@admin_bp.route("/api/admin/usuarios/<int:id_usuario>/bloquear", methods=["PATCH"])
@require_role("admin")
def bloquear_usuario(id_usuario: int):
    data = request.get_json() or {}
    data["idUsuario"] = id_usuario
    payload, status = admin_service.block_user(data)
    return jsonify(payload), status


@admin_bp.route("/api/admin/roles/usuarios", methods=["GET"])
@require_role("admin")
def get_usuarios_roles():
    payload, status = admin_service.list_role_users()
    return jsonify(payload), status


@admin_bp.route("/api/admin/usuarios/<int:id_usuario>/rol", methods=["PATCH"])
@require_role("admin")
def cambiar_rol(id_usuario: int):
    data = request.get_json() or {}
    data["idUsuario"] = id_usuario
    payload, status = admin_service.change_role(data)
    return jsonify(payload), status


@admin_bp.route("/api/admin/roles/historial", methods=["GET"])
@require_role("admin")
def get_historial_roles():
    payload, status = admin_service.role_history()
    return jsonify(payload), status


@admin_bp.route("/api/admin/notificaciones", methods=["GET"])
@require_role("admin")
def get_notificaciones():
    payload, status = admin_service.notifications_feed()
    return jsonify(payload), status


@admin_bp.route("/api/admin/notificaciones", methods=["POST"])
@require_role("admin")
def crear_notificacion():
    payload, status = admin_service.create_notification(request.get_json() or {})
    return jsonify(payload), status


@admin_bp.route("/api/admin/notificaciones/<int:id_notificacion>", methods=["DELETE"])
@require_role("admin")
def eliminar_notificacion(id_notificacion: int):
    payload, status = admin_service.delete_notification(id_notificacion)
    return jsonify(payload), status


@admin_bp.route("/api/admin/logs", methods=["GET"])
@require_role("admin")
def get_logs():
    payload, status = admin_service.get_logs()
    return jsonify(payload), status