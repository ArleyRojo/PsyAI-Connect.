from flask import Blueprint, current_app, jsonify, request, session

from app.services import patient_service
from app.utils.auth import require_role, require_authenticated


patient_bp = Blueprint("patient", __name__)


@patient_bp.route("/api/perfil/paciente/<int:id_usuario>", methods=["GET"])
@require_role("admin", "profesional", "paciente")
def get_perfil_paciente(id_usuario: int):
    auth_error = require_authenticated()
    if auth_error:
        return auth_error

    rol = session.get("rol")
    usuario_id = session.get("idUsuario")

    if rol not in ("admin", "profesional") and int(usuario_id) != id_usuario:
        return jsonify({"success": False, "message": "No autorizado"}), 403

    payload, status = patient_service.get_patient_profile(id_usuario)
    return jsonify(payload), status


@patient_bp.route("/api/perfil/paciente", methods=["PUT"])
@require_role("paciente")
def editar_perfil_paciente():
    data = request.get_json() or {}
    data["idUsuario"] = session.get("idUsuario")
    payload, status = patient_service.update_patient_profile(data)
    return jsonify(payload), status


@patient_bp.route("/api/evolucion", methods=["POST"])
@require_role("paciente")
def guardar_evolucion():
    payload, status = patient_service.save_evolution(session.get("idUsuario"), request.get_json() or {})
    return jsonify(payload), status


@patient_bp.route("/api/evolucion", methods=["GET"])
@require_role("paciente")
def historial_evolucion():
    payload, status = patient_service.get_evolution_history(session.get("idUsuario"))
    return jsonify(payload), status


@patient_bp.route("/api/pacientes", methods=["GET"])
@require_role("profesional", "admin")
def listar_pacientes():
    payload, status = patient_service.list_patients()
    return jsonify(payload), status


@patient_bp.route("/api/profesionales", methods=["GET"])
@require_role("paciente", "profesional", "admin")
def listar_profesionales():
    payload, status = patient_service.list_professionals()
    return jsonify(payload), status