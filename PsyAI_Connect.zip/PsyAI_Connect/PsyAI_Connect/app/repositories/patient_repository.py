from app.utils.db import db_cursor


def update_profile_photo(filename, user_id):
    with db_cursor() as (conn, cursor):
        cursor.execute("UPDATE Register SET fotoPerfil = %s WHERE idUsuario = %s", (filename, user_id))
        conn.commit()


def get_patient_profile(user_id):
    with db_cursor(dictionary=True) as (_, cursor):
        cursor.execute(
            """
            SELECT r.nombre, r.email, r.fotoPerfil, r.fechaRegistro,
                   p.edad, p.genero, p.numeroTelefonico
            FROM Register r
            LEFT JOIN PerfilPaciente p ON r.idUsuario = p.idPaciente
            WHERE r.idUsuario = %s
            """,
            (user_id,),
        )
        return cursor.fetchone()


def update_patient_profile(data):
    with db_cursor() as (conn, cursor):
        cursor.execute(
            """
            UPDATE PerfilPaciente
            SET edad = %s, genero = %s, numeroTelefonico = %s
            WHERE idPaciente = %s
            """,
            (data.get("edad"), data.get("genero"), data.get("numeroTelefonico"), data.get("idUsuario")),
        )
        if cursor.rowcount == 0:
            cursor.execute(
                "INSERT INTO PerfilPaciente (idPaciente, edad, genero, numeroTelefonico) VALUES (%s, %s, %s, %s)",
                (data.get("idUsuario"), data.get("edad"), data.get("genero"), data.get("numeroTelefonico")),
            )
        conn.commit()


def create_patient_evolution(user_id, data):
    with db_cursor() as (conn, cursor):
        cursor.execute(
            """
            INSERT INTO EvolucionPaciente (idPaciente, estadoEmocional, nivelEnergia, notasPersonales)
            VALUES (%s, %s, %s, %s)
            """,
            (user_id, data.get("estadoEmocional"), data.get("nivelEnergia"), data.get("notasPersonales")),
        )
        conn.commit()


def get_patient_evolution_history(user_id):
    with db_cursor(dictionary=True) as (_, cursor):
        cursor.execute(
            """
            SELECT estadoEmocional, nivelEnergia, notasPersonales,
                   DATE_FORMAT(fecha, '%d/%m/%Y') as fecha,
                   fecha as fechaRaw
            FROM EvolucionPaciente
            WHERE idPaciente = %s
            ORDER BY fecha DESC
            """,
            (user_id,),
        )
        return cursor.fetchall()


def list_patients():
    with db_cursor(dictionary=True) as (_, cursor):
        cursor.execute(
            """
            SELECT idUsuario, nombre, email, fotoPerfil FROM Register
            WHERE rol = 'paciente'
            ORDER BY nombre
            """
        )
        return cursor.fetchall()


def list_professionals():
    with db_cursor(dictionary=True) as (_, cursor):
        cursor.execute(
            """
            SELECT idUsuario, nombre FROM Register
            WHERE rol = 'profesional'
            ORDER BY nombre
            """
        )
        return cursor.fetchall()

