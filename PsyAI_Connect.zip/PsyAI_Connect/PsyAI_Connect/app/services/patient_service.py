from app.repositories import patient_repository


def get_patient_profile(user_id):
    perfil = patient_repository.get_patient_profile(user_id)
    if not perfil:
        return {"success": False, "message": "Perfil no encontrado"}, 404
    if perfil.get("fechaRegistro"):
        perfil["fechaRegistro"] = perfil["fechaRegistro"].strftime("%d/%m/%Y")
    return {"success": True, "perfil": perfil}, 200


def update_patient_profile(data):
    patient_repository.update_patient_profile(data)
    return {"success": True, "message": "Perfil actualizado"}, 200


def save_evolution(user_id, data):
    patient_repository.create_patient_evolution(user_id, data)
    return {"success": True, "message": "Evolución guardada correctamente"}, 200


def get_evolution_history(user_id):
    return {"success": True, "historial": patient_repository.get_patient_evolution_history(user_id)}, 200


def list_patients():
    return {"success": True, "pacientes": patient_repository.list_patients()}, 200


def list_professionals():
    return {"success": True, "profesionales": patient_repository.list_professionals()}, 200

