import logging
from app.database.connection import get_connection

logger = logging.getLogger(__name__)

def init_db():
    conn = None
    cursor = None
    try:
        conn = get_connection()
        cursor = conn.cursor()

        create_statements = [
            """
            CREATE TABLE IF NOT EXISTS Register (
                idUsuario INT AUTO_INCREMENT PRIMARY KEY,
                nombre VARCHAR(100) NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                contrasena VARCHAR(255) NOT NULL,
                rol ENUM('admin','paciente','profesional') DEFAULT 'paciente',
                activo TINYINT(1) DEFAULT 1,
                estadoCuenta ENUM('Activa','Suspendida') DEFAULT 'Activa',
                fechaRegistro DATETIME DEFAULT CURRENT_TIMESTAMP,
                fotoPerfil VARCHAR(10) DEFAULT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """,
            """
            CREATE TABLE IF NOT EXISTS PerfilPaciente (
                idPaciente INT PRIMARY KEY,
                genero VARCHAR(20),
                edad INT,
                numeroTelefonico VARCHAR(20),
                FOREIGN KEY (idPaciente) REFERENCES Register(idUsuario) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """,
            """
            CREATE TABLE IF NOT EXISTS PerfilProfesional (
                idProfesional INT PRIMARY KEY,
                especialidad VARCHAR(100),
                licencia VARCHAR(100),
                experiencia INT,
                estado VARCHAR(20) DEFAULT 'Activo',
                FOREIGN KEY (idProfesional) REFERENCES Register(idUsuario) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """,
            """
            CREATE TABLE IF NOT EXISTS AuditoriaAccesos (
                idAuditoria INT AUTO_INCREMENT PRIMARY KEY,
                idUsuario INT NOT NULL,
                accion VARCHAR(50) NOT NULL,
                ip VARCHAR(45) NOT NULL,
                fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (idUsuario) REFERENCES Register(idUsuario) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """,
            """
            CREATE TABLE IF NOT EXISTS Login (
                idLogin INT AUTO_INCREMENT PRIMARY KEY,
                idUsuario INT NOT NULL,
                email VARCHAR(100) NOT NULL,
                fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (idUsuario) REFERENCES Register(idUsuario) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """,
            """
            CREATE TABLE IF NOT EXISTS Disponibilidad (
                idDisponibilidad INT AUTO_INCREMENT PRIMARY KEY,
                idProfesional INT NOT NULL,
                fecha DATE NOT NULL,
                hora_inicio TIME NOT NULL,
                hora_fin TIME NOT NULL,
                estado ENUM('Disponible','Ocupado') DEFAULT 'Disponible',
                FOREIGN KEY (idProfesional) REFERENCES Register(idUsuario) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """,
            """
            CREATE TABLE IF NOT EXISTS Citas (
                idCita INT AUTO_INCREMENT PRIMARY KEY,
                idPaciente INT NOT NULL,
                idProfesional INT NOT NULL,
                fecha DATE NOT NULL,
                hora TIME NOT NULL,
                tipoCita VARCHAR(100) NOT NULL,
                motivo TEXT,
                estado ENUM('Pendiente','Completada','Cancelada') DEFAULT 'Pendiente',
                FOREIGN KEY (idPaciente) REFERENCES Register(idUsuario) ON DELETE CASCADE,
                FOREIGN KEY (idProfesional) REFERENCES Register(idUsuario) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """,
            """
            CREATE TABLE IF NOT EXISTS ConversacionesChatbot (
                idConversacion INT AUTO_INCREMENT PRIMARY KEY,
                idUsuario INT NOT NULL,
                mensaje TEXT NOT NULL,
                respuesta TEXT,
                fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (idUsuario) REFERENCES Register(idUsuario) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """,
            """
            CREATE TABLE IF NOT EXISTS EvolucionPaciente (
                idEvolucion INT AUTO_INCREMENT PRIMARY KEY,
                idPaciente INT NOT NULL,
                estadoEmocional VARCHAR(100),
                nivelEnergia INT,
                notasPersonales TEXT,
                fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (idPaciente) REFERENCES Register(idUsuario) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """,
            """
            CREATE TABLE IF NOT EXISTS PacientesProfesional (
                id INT AUTO_INCREMENT PRIMARY KEY,
                idProfesional INT NOT NULL,
                idPaciente INT NOT NULL,
                sintomas TEXT,
                diagnostico TEXT,
                tratamiento TEXT,
                fechaDiagnostico DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (idProfesional) REFERENCES Register(idUsuario) ON DELETE CASCADE,
                FOREIGN KEY (idPaciente) REFERENCES Register(idUsuario) ON DELETE CASCADE,
                UNIQUE KEY uk_prof_paciente (idProfesional, idPaciente)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """,
            """
            CREATE TABLE IF NOT EXISTS Reportes (
                idReporte INT AUTO_INCREMENT PRIMARY KEY,
                idProfesional INT NOT NULL,
                idPaciente INT DEFAULT NULL,
                tipoReporte VARCHAR(100) NOT NULL,
                fechaInicio DATE,
                fechaFin DATE,
                estado ENUM('Completado','Pendiente') DEFAULT 'Pendiente',
                sintomas TEXT,
                diagnostico TEXT,
                tratamiento TEXT,
                eliminado TINYINT(1) DEFAULT 0,
                FOREIGN KEY (idProfesional) REFERENCES Register(idUsuario) ON DELETE CASCADE,
                FOREIGN KEY (idPaciente) REFERENCES Register(idUsuario) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """,
            """
            CREATE TABLE IF NOT EXISTS Facturas (
                idFactura INT AUTO_INCREMENT PRIMARY KEY,
                idPaciente INT NOT NULL,
                idProfesional INT NOT NULL,
                fecha DATE NOT NULL,
                total DECIMAL(10,2) NOT NULL,
                estado ENUM('Pendiente','Pagada','Cancelada') DEFAULT 'Pendiente',
                FOREIGN KEY (idPaciente) REFERENCES Register(idUsuario) ON DELETE CASCADE,
                FOREIGN KEY (idProfesional) REFERENCES Register(idUsuario) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """,
            """
            CREATE TABLE IF NOT EXISTS ItemsFactura (
                idItem INT AUTO_INCREMENT PRIMARY KEY,
                idFactura INT NOT NULL,
                descripcion VARCHAR(255),
                cantidad INT DEFAULT 1,
                precio DECIMAL(10,2) NOT NULL,
                FOREIGN KEY (idFactura) REFERENCES Facturas(idFactura) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """,
            """
            CREATE TABLE IF NOT EXISTS Notificaciones (
                idNotificacion INT AUTO_INCREMENT PRIMARY KEY,
                idUsuario INT DEFAULT NULL,
                rol ENUM('admin','profesional','paciente') DEFAULT NULL,
                titulo VARCHAR(255) NOT NULL,
                mensaje TEXT NOT NULL,
                tipo VARCHAR(50) DEFAULT 'info',
                destinatario VARCHAR(100),
                email_individual VARCHAR(100),
                enviado_por VARCHAR(100) DEFAULT 'Admin',
                estado ENUM('enviado','pendiente') DEFAULT 'pendiente',
                leido TINYINT(1) DEFAULT 0,
                fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
                fecha_programada DATETIME DEFAULT NULL,
                FOREIGN KEY (idUsuario) REFERENCES Register(idUsuario) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """,
            """
            CREATE TABLE IF NOT EXISTS Logs (
                idLog INT AUTO_INCREMENT PRIMARY KEY,
                administrador VARCHAR(100) NOT NULL,
                modulo VARCHAR(50) NOT NULL,
                accion VARCHAR(50) NOT NULL,
                detalle TEXT,
                fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
                rol_anterior VARCHAR(20) DEFAULT NULL,
                rol_nuevo VARCHAR(20) DEFAULT NULL,
                usuario_afectado VARCHAR(100) DEFAULT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """,
            """
            CREATE TABLE IF NOT EXISTS RecoveryTokens (
                idToken INT AUTO_INCREMENT PRIMARY KEY,
                idUsuario INT NOT NULL,
                token VARCHAR(100) UNIQUE NOT NULL,
                expires DATETIME NOT NULL,
                used TINYINT(1) DEFAULT 0,
                FOREIGN KEY (idUsuario) REFERENCES Register(idUsuario) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """
        ]

        for stmt in create_statements:
            cursor.execute(stmt)

        # Columnas adicionales para tablas existentes
        extra_alters = []
        cursor.execute("""
            SELECT COUNT(*) FROM information_schema.COLUMNS 
            WHERE TABLE_NAME = 'Logs' AND COLUMN_NAME = 'rol_anterior' AND TABLE_SCHEMA = DATABASE()
        """)
        if cursor.fetchone()[0] == 0:
            extra_alters.append("ALTER TABLE Logs ADD COLUMN rol_anterior VARCHAR(20) DEFAULT NULL")
        
        cursor.execute("""
            SELECT COUNT(*) FROM information_schema.COLUMNS 
            WHERE TABLE_NAME = 'Logs' AND COLUMN_NAME = 'rol_nuevo' AND TABLE_SCHEMA = DATABASE()
        """)
        if cursor.fetchone()[0] == 0:
            extra_alters.append("ALTER TABLE Logs ADD COLUMN rol_nuevo VARCHAR(20) DEFAULT NULL")
        
        cursor.execute("""
            SELECT COUNT(*) FROM information_schema.COLUMNS 
            WHERE TABLE_NAME = 'Logs' AND COLUMN_NAME = 'usuario_afectado' AND TABLE_SCHEMA = DATABASE()
        """)
        if cursor.fetchone()[0] == 0:
            extra_alters.append("ALTER TABLE Logs ADD COLUMN usuario_afectado VARCHAR(100) DEFAULT NULL")
        
        cursor.execute("""
            SELECT COUNT(*) FROM information_schema.COLUMNS 
            WHERE TABLE_NAME = 'Reportes' AND COLUMN_NAME = 'eliminado' AND TABLE_SCHEMA = DATABASE()
        """)
        if cursor.fetchone()[0] == 0:
            extra_alters.append("ALTER TABLE Reportes ADD COLUMN eliminado TINYINT(1) DEFAULT 0")

        cursor.execute("""
            SELECT COUNT(*) FROM information_schema.COLUMNS 
            WHERE TABLE_NAME = 'Citas' AND COLUMN_NAME = 'motivoCancelacion' AND TABLE_SCHEMA = DATABASE()
        """)
        if cursor.fetchone()[0] == 0:
            extra_alters.append("ALTER TABLE Citas ADD COLUMN motivoCancelacion TEXT DEFAULT NULL")

        cursor.execute("""
            SELECT COUNT(*) FROM information_schema.COLUMNS 
            WHERE TABLE_NAME = 'Notificaciones' AND COLUMN_NAME = 'rol' AND TABLE_SCHEMA = DATABASE()
        """)
        if cursor.fetchone()[0] == 0:
            extra_alters.append("ALTER TABLE Notificaciones ADD COLUMN rol ENUM('admin','profesional','paciente') DEFAULT NULL")

        
        for alter in extra_alters:
            cursor.execute(alter)

        # Limpiar fotos antiguas (se usan avatares por inicial en frontend)
        cursor.execute("UPDATE Register SET fotoPerfil = NULL WHERE fotoPerfil IS NOT NULL")

        conn.commit()
        logger.info("Base de datos inicializada correctamente")
    except Exception as e:
        if conn:
            try:
                conn.rollback()
            except Exception:
                pass
        logger.error(f"Error inicializando DB: {e}")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()
